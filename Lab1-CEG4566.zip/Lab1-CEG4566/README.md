## Youtube Demos

Partie 1: Simulation du Cycle des Feux de Circulation pour Véhicules : https://www.youtube.com/shorts/G6IoNlShRbs


Partie 2: Intégration des Feux pour Piétons et Gestion des Interactions: https://www.youtube.com/shorts/MZTcU0jz888
